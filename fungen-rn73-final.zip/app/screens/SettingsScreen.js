import React from 'react';
import {View, Text} from 'react-native';
export default function SettingsScreen(){ return (<View style={{padding:16}}><Text>Settings</Text></View>); }
