FunGen RN 0.73.5 full scaffold for package com.ramkumar.fungen
Follow README in project for build steps.
