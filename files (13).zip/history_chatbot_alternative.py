"""
Historical Figures Chatbot with LangSmith Integration
Alternative Version: FAISS + HuggingFace Option

A RAG-based chatbot with alternative implementations:
- Vector Store: FAISS instead of Chroma
- LLM: HuggingFace Endpoint option
"""

import os
from typing import List, Tuple
import gradio as gr

# LangChain imports
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import ChatMessageHistory

# LLM options
from langchain_community.llms import Ollama
# Uncomment below for HuggingFace
# from langchain_community.llms import HuggingFaceEndpoint

# LangSmith configuration
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_PROJECT"] = "Historical-Figures-Chatbot-Alternative"
# Set your LangSmith API key here or in environment variables
# os.environ["LANGCHAIN_API_KEY"] = "your-api-key-here"

# Configuration
USE_HUGGINGFACE = False  # Set to True to use HuggingFace instead of Ollama
HUGGINGFACE_MODEL = "mistralai/Mistral-7B-Instruct-v0.2"  # or "Menlo/Jan-nano-128k"
# os.environ["HUGGINGFACEHUB_API_TOKEN"] = "your-hf-token-here"

# Global variables
vector_store = None
qa_chain = None
chat_history = ChatMessageHistory()
conversation_memory = None


def initialize_chatbot(pdf_path: str = "Historical_figures.pdf"):
    """
    Initialize the chatbot with FAISS vector store and optional HuggingFace LLM.
    
    Args:
        pdf_path: Path to the Historical_figures.pdf file
    """
    global vector_store, qa_chain, conversation_memory
    
    print("🔄 Initializing Historical Figures Chatbot (Alternative Version)...")
    
    # Step 1: Load PDF
    print(f"📄 Loading PDF from: {pdf_path}")
    try:
        loader = PyPDFLoader(pdf_path)
        documents = loader.load()
        print(f"✅ Loaded {len(documents)} pages from PDF")
    except Exception as e:
        print(f"❌ Error loading PDF: {e}")
        raise
    
    # Step 2: Split documents
    print("✂️  Splitting documents...")
    text_splitter = CharacterTextSplitter(
        chunk_size=200,
        chunk_overlap=30,
        separator="\n"
    )
    texts = text_splitter.split_documents(documents)
    print(f"✅ Created {len(texts)} text chunks")
    
    # Step 3: Create embeddings
    print("🧠 Initializing Ollama embeddings (granite-embedding:latest)...")
    try:
        embeddings = OllamaEmbeddings(model="granite-embedding:latest")
        print("✅ Embeddings initialized")
    except Exception as e:
        print(f"❌ Error initializing embeddings: {e}")
        raise
    
    # Step 4: Create FAISS vector store
    print("🗄️  Creating FAISS vector store...")
    try:
        vector_store = FAISS.from_documents(
            documents=texts,
            embedding=embeddings
        )
        # Save the vector store locally
        vector_store.save_local("faiss_index_historical_figures")
        print("✅ FAISS vector store created and saved successfully")
    except Exception as e:
        print(f"❌ Error creating FAISS vector store: {e}")
        raise
    
    # Step 5: Initialize LLM
    if USE_HUGGINGFACE:
        print(f"🤖 Initializing HuggingFace LLM ({HUGGINGFACE_MODEL})...")
        try:
            from langchain_community.llms import HuggingFaceEndpoint
            llm = HuggingFaceEndpoint(
                repo_id=HUGGINGFACE_MODEL,
                temperature=0.7,
                max_new_tokens=512
            )
            print("✅ HuggingFace LLM initialized")
        except Exception as e:
            print(f"❌ Error initializing HuggingFace LLM: {e}")
            print("   Make sure HUGGINGFACEHUB_API_TOKEN is set")
            raise
    else:
        print("🤖 Initializing Ollama LLM (llama3)...")
        try:
            llm = Ollama(
                model="llama3",
                temperature=0.7
            )
            print("✅ Ollama LLM initialized")
        except Exception as e:
            print(f"❌ Error initializing Ollama LLM: {e}")
            raise
    
    # Step 6: Create custom prompt template
    custom_template = """You are HistoryBot, an expert on historical figures. Use the following pieces of context to answer the question at the end. 
    
If you don't know the answer based on the context provided, just say "I don't have information about that in my knowledge base." Don't try to make up an answer.

Always be informative, accurate, and engaging in your responses about historical figures.

Context: {context}

Question: {question}

Helpful Answer:"""
    
    CUSTOM_PROMPT = PromptTemplate(
        template=custom_template,
        input_variables=["context", "question"]
    )
    
    # Step 7: Initialize conversation memory
    conversation_memory = ConversationBufferMemory(
        chat_memory=chat_history,
        memory_key="chat_history",
        return_messages=True
    )
    
    # Step 8: Create RetrievalQA chain
    print("🔗 Creating RetrievalQA chain...")
    try:
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=vector_store.as_retriever(search_kwargs={"k": 3}),
            chain_type_kwargs={"prompt": CUSTOM_PROMPT},
            return_source_documents=True
        )
        print("✅ QA chain created successfully")
    except Exception as e:
        print(f"❌ Error creating QA chain: {e}")
        raise
    
    llm_info = "HuggingFace" if USE_HUGGINGFACE else "Ollama"
    print(f"🎉 Chatbot initialization complete! Using FAISS + {llm_info}")
    return f"Chatbot initialized successfully with FAISS + {llm_info}!"


def chat(message: str, history: List[Tuple[str, str]]) -> Tuple[str, List[Tuple[str, str]]]:
    """
    Process user message and generate response.
    
    Args:
        message: User input message
        history: Chat history as list of tuples (user_msg, bot_msg)
    
    Returns:
        Tuple of (response, updated_history)
    """
    global qa_chain, chat_history
    
    if qa_chain is None:
        return "⚠️ Chatbot not initialized. Please make sure the PDF is loaded and the system is initialized.", history
    
    try:
        # Add user message to chat history
        chat_history.add_user_message(message)
        
        # Get response from QA chain
        result = qa_chain({"query": message})
        response = result["result"]
        
        # Add assistant response to chat history
        chat_history.add_ai_message(response)
        
        # Update Gradio history
        history.append((message, response))
        
        return "", history
    
    except Exception as e:
        error_msg = f"❌ Error processing your question: {str(e)}"
        history.append((message, error_msg))
        return "", history


def clear_history() -> Tuple[str, List]:
    """
    Clear the chat history.
    
    Returns:
        Empty message and empty history list
    """
    global chat_history
    chat_history.clear()
    return "", []


def load_existing_index():
    """
    Load an existing FAISS index if available.
    """
    global vector_store
    
    try:
        print("🔄 Attempting to load existing FAISS index...")
        embeddings = OllamaEmbeddings(model="granite-embedding:latest")
        vector_store = FAISS.load_local(
            "faiss_index_historical_figures",
            embeddings,
            allow_dangerous_deserialization=True
        )
        print("✅ Existing FAISS index loaded successfully")
        return True
    except Exception as e:
        print(f"ℹ️  No existing index found or error loading: {e}")
        return False


def create_gradio_interface():
    """
    Create and configure the Gradio interface.
    """
    llm_info = "HuggingFace" if USE_HUGGINGFACE else "Ollama"
    
    # Custom CSS for better styling
    custom_css = """
    #chatbot {
        height: 500px;
        overflow-y: auto;
    }
    #title {
        text-align: center;
        font-size: 2em;
        font-weight: bold;
        margin-bottom: 10px;
    }
    #greeting {
        text-align: center;
        font-style: italic;
        color: #666;
        margin-bottom: 20px;
    }
    """
    
    with gr.Blocks(css=custom_css, title="Historical Figures Chatbot") as demo:
        gr.Markdown(
            """
            <div id="title">🏛️ Historical Figures Chatbot (Alternative)</div>
            <div id="greeting">Hello, I am HistoryBot, your expert on historical figures. How can I assist you today?</div>
            """,
            elem_id="header"
        )
        
        chatbot = gr.Chatbot(
            elem_id="chatbot",
            label="Chat History",
            show_label=True,
            height=500
        )
        
        with gr.Row():
            msg = gr.Textbox(
                label="Your Question",
                placeholder="Ask me anything about historical figures...",
                scale=4
            )
        
        with gr.Row():
            submit_btn = gr.Button("Submit", variant="primary", scale=1)
            clear_btn = gr.Button("Clear History", scale=1)
        
        gr.Markdown(
            f"""
            ### 💡 Tips:
            - Ask about famous historical figures, their achievements, and contributions
            - Request information about specific time periods or events
            - Compare different historical figures
            
            ### 🔧 System Info:
            - **Vector Store**: FAISS with Ollama Embeddings (granite-embedding:latest)
            - **LLM**: {llm_info}
            - **Tracking**: LangSmith enabled for conversation tracing
            """
        )
        
        # Event handlers
        msg.submit(chat, inputs=[msg, chatbot], outputs=[msg, chatbot])
        submit_btn.click(chat, inputs=[msg, chatbot], outputs=[msg, chatbot])
        clear_btn.click(clear_history, outputs=[msg, chatbot])
    
    return demo


def main():
    """
    Main function to run the chatbot application.
    """
    print("=" * 70)
    print("🏛️  HISTORICAL FIGURES CHATBOT - ALTERNATIVE VERSION")
    print("    (FAISS Vector Store + Optional HuggingFace)")
    print("=" * 70)
    
    # Check for LangSmith API key
    if "LANGCHAIN_API_KEY" not in os.environ:
        print("\n⚠️  Warning: LANGCHAIN_API_KEY not set in environment variables.")
        print("   LangSmith tracing may not work. Please set it with:")
        print("   export LANGCHAIN_API_KEY='your-api-key-here'")
        print("   or add it directly in the script.\n")
    
    # Check for HuggingFace token if using HuggingFace
    if USE_HUGGINGFACE and "HUGGINGFACEHUB_API_TOKEN" not in os.environ:
        print("\n⚠️  Warning: HUGGINGFACEHUB_API_TOKEN not set in environment variables.")
        print("   HuggingFace LLM will not work. Please set it with:")
        print("   export HUGGINGFACEHUB_API_TOKEN='your-token-here'")
        print("   or add it directly in the script.\n")
    
    # Initialize chatbot
    pdf_path = "Historical_figures.pdf"
    
    # Check if PDF exists
    if not os.path.exists(pdf_path):
        print(f"\n⚠️  Warning: {pdf_path} not found in current directory.")
        print(f"   Please ensure the PDF file is in the same directory as this script.")
        
        # Try to load existing FAISS index
        if load_existing_index():
            print("   Using existing FAISS index instead.\n")
        else:
            print("   No existing index found. Exiting.\n")
            return
    else:
        try:
            initialize_chatbot(pdf_path)
        except Exception as e:
            print(f"\n❌ Failed to initialize chatbot: {e}")
            print("\n📋 Troubleshooting steps:")
            print("1. Ensure 'Historical_figures.pdf' is in the current directory")
            print("2. Verify Ollama is installed and running: ollama serve")
            print("3. Pull required models:")
            print("   - ollama pull llama3")
            print("   - ollama pull granite-embedding:latest")
            if USE_HUGGINGFACE:
                print("4. Check your HuggingFace API token is set correctly")
            print("5. Check your LangSmith API key is set correctly")
            return
    
    # Create and launch Gradio interface
    print("\n🚀 Launching Gradio interface...")
    demo = create_gradio_interface()
    demo.launch(
        share=False,
        server_name="0.0.0.0",
        server_port=7861  # Different port to avoid conflicts
    )


if __name__ == "__main__":
    main()
