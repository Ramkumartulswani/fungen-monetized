"""
PDF Generator for Historical Figures Chatbot Project
This script creates a comprehensive PDF document with all project files and instructions.
"""

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Preformatted
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.pdfgen import canvas
from datetime import datetime
import os

def create_project_pdf(output_filename="Historical_Figures_Chatbot_Project.pdf"):
    """
    Create a comprehensive PDF document with all project information.
    """
    
    # Create the PDF document
    doc = SimpleDocTemplate(
        output_filename,
        pagesize=letter,
        rightMargin=0.75*inch,
        leftMargin=0.75*inch,
        topMargin=0.75*inch,
        bottomMargin=0.75*inch
    )
    
    # Container for the 'Flowable' objects
    elements = []
    
    # Define styles
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1a1a1a'),
        spaceAfter=30,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading1_style = ParagraphStyle(
        'CustomHeading1',
        parent=styles['Heading1'],
        fontSize=16,
        textColor=colors.HexColor('#2c5aa0'),
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    heading2_style = ParagraphStyle(
        'CustomHeading2',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#2c5aa0'),
        spaceAfter=10,
        spaceBefore=10,
        fontName='Helvetica-Bold'
    )
    
    code_style = ParagraphStyle(
        'Code',
        parent=styles['Code'],
        fontSize=8,
        fontName='Courier',
        textColor=colors.HexColor('#1a1a1a'),
        backColor=colors.HexColor('#f5f5f5'),
        leftIndent=20,
        rightIndent=20,
        spaceAfter=10,
        spaceBefore=10
    )
    
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['BodyText'],
        fontSize=10,
        alignment=TA_JUSTIFY,
        spaceAfter=10
    )
    
    # Title Page
    elements.append(Spacer(1, 1.5*inch))
    elements.append(Paragraph("Historical Figures Chatbot", title_style))
    elements.append(Paragraph("with LangSmith Integration", title_style))
    elements.append(Spacer(1, 0.5*inch))
    elements.append(Paragraph("Complete Project Documentation", heading2_style))
    elements.append(Spacer(1, 0.3*inch))
    elements.append(Paragraph(f"Generated: {datetime.now().strftime('%B %d, %Y')}", body_style))
    elements.append(Spacer(1, 0.5*inch))
    
    # Project overview
    overview_text = """
    A Retrieval-Augmented Generation (RAG) based chatbot built with LangChain that answers 
    questions about historical figures from a PDF knowledge base. Features include PDF ingestion, 
    vector storage with Chroma/FAISS, local LLM integration with Ollama, conversation memory, 
    LangSmith tracing, and a user-friendly Gradio interface.
    """
    elements.append(Paragraph(overview_text, body_style))
    
    elements.append(PageBreak())
    
    # Table of Contents
    elements.append(Paragraph("Table of Contents", heading1_style))
    toc_data = [
        ["1.", "Project Overview", "3"],
        ["2.", "Requirements & Dependencies", "4"],
        ["3.", "Setup Instructions", "5"],
        ["4.", "Main Code: history_chatbot.py", "7"],
        ["5.", "Alternative Code: FAISS + HuggingFace", "15"],
        ["6.", "Configuration Files", "22"],
        ["7.", "Usage Guide", "24"],
        ["8.", "Troubleshooting", "26"],
    ]
    
    toc_table = Table(toc_data, colWidths=[0.5*inch, 4*inch, 0.5*inch])
    toc_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    elements.append(toc_table)
    
    elements.append(PageBreak())
    
    # Section 1: Project Overview
    elements.append(Paragraph("1. Project Overview", heading1_style))
    
    elements.append(Paragraph("Features", heading2_style))
    features = [
        "PDF Ingestion: Load historical figures PDF using PyPDFLoader",
        "Smart Text Splitting: CharacterTextSplitter with chunk_size=200 and chunk_overlap=30",
        "Vector Store: Chroma or FAISS with OllamaEmbeddings (granite-embedding:latest)",
        "LLM Integration: Local Ollama (llama3) or HuggingFace Endpoint",
        "Conversation Memory: In-memory chat history tracking",
        "LangSmith Tracing: Full conversation and retrieval tracing",
        "Gradio UI: User-friendly web interface with chat history"
    ]
    for feature in features:
        elements.append(Paragraph(f"• {feature}", body_style))
    
    elements.append(Spacer(1, 0.2*inch))
    
    elements.append(Paragraph("Architecture", heading2_style))
    arch_text = """
    The chatbot follows a RAG (Retrieval-Augmented Generation) architecture:
    1. PDF documents are loaded and split into chunks
    2. Chunks are embedded and stored in a vector database
    3. User queries retrieve relevant chunks
    4. Retrieved context is provided to the LLM for generation
    5. Responses are tracked with conversation memory
    6. All interactions are traced via LangSmith
    """
    elements.append(Paragraph(arch_text, body_style))
    
    elements.append(PageBreak())
    
    # Section 2: Requirements
    elements.append(Paragraph("2. Requirements & Dependencies", heading1_style))
    
    elements.append(Paragraph("System Requirements", heading2_style))
    sys_reqs = [
        "Python 3.9 or higher",
        "Ollama installed and running",
        "4GB RAM minimum (8GB recommended)",
        "2GB free disk space for models"
    ]
    for req in sys_reqs:
        elements.append(Paragraph(f"• {req}", body_style))
    
    elements.append(Spacer(1, 0.2*inch))
    
    elements.append(Paragraph("Python Dependencies (requirements.txt)", heading2_style))
    
    requirements_code = """
# Core LangChain libraries
langchain==0.1.0
langchain-community==0.0.10
langsmith==0.0.77

# Document processing
pypdf==3.17.4

# Vector stores
chromadb==0.4.22

# Embeddings and LLM
ollama==0.1.6

# UI
gradio==4.13.0

# Additional dependencies
tiktoken==0.5.2
pydantic==2.5.3
requests==2.31.0
"""
    
    elements.append(Preformatted(requirements_code, code_style))
    
    elements.append(PageBreak())
    
    # Section 3: Setup Instructions
    elements.append(Paragraph("3. Setup Instructions", heading1_style))
    
    elements.append(Paragraph("Step 1: Install Ollama", heading2_style))
    setup_text = """
    Visit https://ollama.ai/ and download Ollama for your operating system.
    
    For Linux/Mac:
    """
    elements.append(Paragraph(setup_text, body_style))
    
    setup_code = """
curl -fsSL https://ollama.ai/install.sh | sh
"""
    elements.append(Preformatted(setup_code, code_style))
    
    elements.append(Paragraph("Step 2: Pull Required Models", heading2_style))
    models_code = """
ollama pull llama3
ollama pull granite-embedding:latest

# Verify installation
ollama list
"""
    elements.append(Preformatted(models_code, code_style))
    
    elements.append(Paragraph("Step 3: Setup Python Environment", heading2_style))
    python_setup = """
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On Linux/Mac:
source venv/bin/activate

# On Windows:
venv\\Scripts\\activate

# Install dependencies
pip install -r requirements.txt
"""
    elements.append(Preformatted(python_setup, code_style))
    
    elements.append(Paragraph("Step 4: Configure LangSmith (Optional)", heading2_style))
    langsmith_text = """
    1. Sign up at https://smith.langchain.com/
    2. Get your API key from settings
    3. Set environment variables:
    """
    elements.append(Paragraph(langsmith_text, body_style))
    
    langsmith_code = """
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_PROJECT="Historical-Figures-Chatbot"
export LANGCHAIN_API_KEY="your-api-key-here"
"""
    elements.append(Preformatted(langsmith_code, code_style))
    
    elements.append(Paragraph("Step 5: Prepare Your PDF", heading2_style))
    elements.append(Paragraph("Place Historical_figures.pdf in the same directory as the script.", body_style))
    
    elements.append(PageBreak())
    
    # Section 4: Main Code
    elements.append(Paragraph("4. Main Code: history_chatbot.py", heading1_style))
    elements.append(Paragraph("Core Implementation with Chroma and Ollama", heading2_style))
    
    main_code_part1 = '''
"""
Historical Figures Chatbot with LangSmith Integration
"""

import os
from typing import List, Tuple
import gradio as gr

# LangChain imports
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.llms import Ollama
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import ChatMessageHistory

# LangSmith configuration
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_PROJECT"] = "Historical-Figures-Chatbot"
# os.environ["LANGCHAIN_API_KEY"] = "your-api-key-here"

# Global variables
vector_store = None
qa_chain = None
chat_history = ChatMessageHistory()
conversation_memory = None
'''
    elements.append(Preformatted(main_code_part1, code_style))
    
    elements.append(PageBreak())
    
    main_code_part2 = '''
def initialize_chatbot(pdf_path: str = "Historical_figures.pdf"):
    """Initialize the chatbot with PDF loading and vector store."""
    global vector_store, qa_chain, conversation_memory
    
    print("Initializing Historical Figures Chatbot...")
    
    # Step 1: Load PDF
    loader = PyPDFLoader(pdf_path)
    documents = loader.load()
    print(f"Loaded {len(documents)} pages from PDF")
    
    # Step 2: Split documents
    text_splitter = CharacterTextSplitter(
        chunk_size=200,
        chunk_overlap=30,
        separator="\\n"
    )
    texts = text_splitter.split_documents(documents)
    print(f"Created {len(texts)} text chunks")
    
    # Step 3: Create embeddings
    embeddings = OllamaEmbeddings(model="granite-embedding:latest")
    
    # Step 4: Create vector store
    vector_store = Chroma.from_documents(
        documents=texts,
        embedding=embeddings,
        collection_name="historical_figures",
        persist_directory="./chroma_db"
    )
    
    # Step 5: Initialize LLM
    llm = Ollama(model="llama3", temperature=0.7)
'''
    elements.append(Preformatted(main_code_part2, code_style))
    
    elements.append(PageBreak())
    
    main_code_part3 = '''
    # Step 6: Create custom prompt template
    custom_template = """You are HistoryBot, an expert on historical 
    figures. Use the following context to answer the question.
    
    Context: {context}
    Question: {question}
    
    Helpful Answer:"""
    
    CUSTOM_PROMPT = PromptTemplate(
        template=custom_template,
        input_variables=["context", "question"]
    )
    
    # Step 7: Initialize memory
    conversation_memory = ConversationBufferMemory(
        chat_memory=chat_history,
        memory_key="chat_history",
        return_messages=True
    )
    
    # Step 8: Create RetrievalQA chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=vector_store.as_retriever(search_kwargs={"k": 3}),
        chain_type_kwargs={"prompt": CUSTOM_PROMPT},
        return_source_documents=True
    )
    
    print("Chatbot initialization complete!")
    return "Chatbot initialized successfully!"
'''
    elements.append(Preformatted(main_code_part3, code_style))
    
    elements.append(PageBreak())
    
    main_code_part4 = '''
def chat(message: str, history: List[Tuple[str, str]]):
    """Process user message and generate response."""
    global qa_chain, chat_history
    
    if qa_chain is None:
        return "Chatbot not initialized.", history
    
    try:
        # Add user message to history
        chat_history.add_user_message(message)
        
        # Get response from QA chain
        result = qa_chain({"query": message})
        response = result["result"]
        
        # Add assistant response to history
        chat_history.add_ai_message(response)
        
        # Update Gradio history
        history.append((message, response))
        
        return "", history
    except Exception as e:
        error_msg = f"Error: {str(e)}"
        history.append((message, error_msg))
        return "", history


def clear_history():
    """Clear the chat history."""
    global chat_history
    chat_history.clear()
    return "", []
'''
    elements.append(Preformatted(main_code_part4, code_style))
    
    elements.append(PageBreak())
    
    main_code_part5 = '''
def create_gradio_interface():
    """Create and configure the Gradio interface."""
    
    with gr.Blocks(title="Historical Figures Chatbot") as demo:
        gr.Markdown(
            """
            # Historical Figures Chatbot
            ### Hello, I am HistoryBot, your expert on historical 
            figures. How can I assist you today?
            """
        )
        
        chatbot = gr.Chatbot(
            label="Chat History",
            height=500
        )
        
        msg = gr.Textbox(
            label="Your Question",
            placeholder="Ask me anything about historical figures..."
        )
        
        with gr.Row():
            submit_btn = gr.Button("Submit", variant="primary")
            clear_btn = gr.Button("Clear History")
        
        # Event handlers
        msg.submit(chat, inputs=[msg, chatbot], outputs=[msg, chatbot])
        submit_btn.click(chat, inputs=[msg, chatbot], 
                        outputs=[msg, chatbot])
        clear_btn.click(clear_history, outputs=[msg, chatbot])
    
    return demo


def main():
    """Main function to run the chatbot."""
    print("=" * 60)
    print("HISTORICAL FIGURES CHATBOT WITH LANGSMITH")
    print("=" * 60)
    
    # Initialize chatbot
    pdf_path = "Historical_figures.pdf"
    
    try:
        initialize_chatbot(pdf_path)
    except Exception as e:
        print(f"Failed to initialize: {e}")
        return
    
    # Launch Gradio interface
    demo = create_gradio_interface()
    demo.launch(share=False, server_name="0.0.0.0", 
                server_port=7860)


if __name__ == "__main__":
    main()
'''
    elements.append(Preformatted(main_code_part5, code_style))
    
    elements.append(PageBreak())
    
    # Section 5: Alternative Implementation
    elements.append(Paragraph("5. Alternative Code: FAISS + HuggingFace", heading1_style))
    elements.append(Paragraph("Alternative implementation with FAISS vector store and optional HuggingFace LLM", heading2_style))
    
    alt_code_part1 = '''
"""
Alternative Version: FAISS + HuggingFace Option
"""

# Additional imports for alternative version
from langchain_community.vectorstores import FAISS
# Uncomment for HuggingFace
# from langchain_community.llms import HuggingFaceEndpoint

# Configuration
USE_HUGGINGFACE = False  # Set to True for HuggingFace
HUGGINGFACE_MODEL = "mistralai/Mistral-7B-Instruct-v0.2"
# os.environ["HUGGINGFACEHUB_API_TOKEN"] = "your-token"

def initialize_chatbot_alternative(pdf_path: str):
    """Initialize with FAISS vector store."""
    global vector_store, qa_chain
    
    # Load and split PDF (same as main version)
    loader = PyPDFLoader(pdf_path)
    documents = loader.load()
    
    text_splitter = CharacterTextSplitter(
        chunk_size=200,
        chunk_overlap=30
    )
    texts = text_splitter.split_documents(documents)
    
    # Create embeddings
    embeddings = OllamaEmbeddings(model="granite-embedding:latest")
'''
    elements.append(Preformatted(alt_code_part1, code_style))
    
    elements.append(PageBreak())
    
    alt_code_part2 = '''
    # Create FAISS vector store
    vector_store = FAISS.from_documents(
        documents=texts,
        embedding=embeddings
    )
    # Save locally
    vector_store.save_local("faiss_index_historical_figures")
    
    # Initialize LLM (Ollama or HuggingFace)
    if USE_HUGGINGFACE:
        from langchain_community.llms import HuggingFaceEndpoint
        llm = HuggingFaceEndpoint(
            repo_id=HUGGINGFACE_MODEL,
            temperature=0.7,
            max_new_tokens=512
        )
    else:
        llm = Ollama(model="llama3", temperature=0.7)
    
    # Create QA chain (same as main version)
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=vector_store.as_retriever(search_kwargs={"k": 3}),
        return_source_documents=True
    )
    
    return "Alternative chatbot initialized!"


def load_existing_faiss_index():
    """Load existing FAISS index if available."""
    global vector_store
    
    try:
        embeddings = OllamaEmbeddings(
            model="granite-embedding:latest"
        )
        vector_store = FAISS.load_local(
            "faiss_index_historical_figures",
            embeddings,
            allow_dangerous_deserialization=True
        )
        return True
    except Exception as e:
        print(f"No existing index: {e}")
        return False
'''
    elements.append(Preformatted(alt_code_part2, code_style))
    
    elements.append(PageBreak())
    
    # Section 6: Configuration Files
    elements.append(Paragraph("6. Configuration Files", heading1_style))
    
    elements.append(Paragraph("Setup Script (setup.sh)", heading2_style))
    setup_script = '''
#!/bin/bash

echo "Historical Figures Chatbot Setup"

# Check Python version
python3 --version

# Check Ollama
if command -v ollama &> /dev/null; then
    echo "Ollama is installed"
else
    echo "Please install Ollama from https://ollama.ai/"
    exit 1
fi

# Pull models
ollama pull llama3
ollama pull granite-embedding:latest

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install requirements
pip install -r requirements.txt

echo "Setup complete!"
echo "Run: python history_chatbot.py"
'''
    elements.append(Preformatted(setup_script, code_style))
    
    elements.append(PageBreak())
    
    # Section 7: Usage Guide
    elements.append(Paragraph("7. Usage Guide", heading1_style))
    
    elements.append(Paragraph("Running the Chatbot", heading2_style))
    usage_text = """
    1. Ensure Ollama is running: ollama serve
    2. Activate virtual environment: source venv/bin/activate
    3. Run the chatbot: python history_chatbot.py
    4. Open browser to: http://localhost:7860
    """
    elements.append(Paragraph(usage_text, body_style))
    
    elements.append(Paragraph("Example Questions", heading2_style))
    examples = [
        '"Who was Albert Einstein?"',
        '"Tell me about Marie Curie\'s contributions to science"',
        '"What did Leonardo da Vinci accomplish?"',
        '"Compare Mahatma Gandhi and Martin Luther King Jr."',
        '"When did Cleopatra rule Egypt?"'
    ]
    for ex in examples:
        elements.append(Paragraph(f"• {ex}", body_style))
    
    elements.append(Spacer(1, 0.2*inch))
    
    elements.append(Paragraph("Customization Options", heading2_style))
    custom_text = """
    You can customize various parameters in the code:
    
    • chunk_size: Adjust text chunk size (default: 200)
    • chunk_overlap: Adjust overlap between chunks (default: 30)
    • k: Number of documents to retrieve (default: 3)
    • temperature: LLM creativity level (default: 0.7)
    • model: Change LLM model (llama3, mistral, etc.)
    """
    elements.append(Paragraph(custom_text, body_style))
    
    elements.append(PageBreak())
    
    # Section 8: Troubleshooting
    elements.append(Paragraph("8. Troubleshooting", heading1_style))
    
    troubleshooting_data = [
        ["Issue", "Solution"],
        ["PDF not found", "Place Historical_figures.pdf in same directory"],
        ["Ollama connection error", "Run 'ollama serve' to start Ollama"],
        ["Model not found", "Pull models: ollama pull llama3"],
        ["Module import error", "Install requirements: pip install -r requirements.txt"],
        ["LangSmith not working", "Set LANGCHAIN_API_KEY environment variable"],
        ["Port already in use", "Change server_port in code"],
        ["Memory/Performance issues", "Reduce chunk_size or k parameter"],
    ]
    
    trouble_table = Table(troubleshooting_data, colWidths=[2.5*inch, 4*inch])
    trouble_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(trouble_table)
    
    elements.append(Spacer(1, 0.3*inch))
    
    elements.append(Paragraph("Additional Support", heading2_style))
    support_text = """
    For more help:
    • Check terminal logs for detailed error messages
    • Visit LangChain documentation: https://python.langchain.com/
    • Review Ollama docs: https://ollama.ai/
    • Check Gradio docs: https://gradio.app/docs/
    
    LangSmith Dashboard: https://smith.langchain.com/
    """
    elements.append(Paragraph(support_text, body_style))
    
    elements.append(PageBreak())
    
    # Final page - Summary
    elements.append(Paragraph("Project Summary", heading1_style))
    
    summary_text = """
    This Historical Figures Chatbot project provides a complete RAG-based solution for 
    answering questions about historical figures. The implementation includes:
    
    ✓ Two versions: Chroma and FAISS vector stores
    ✓ Flexible LLM options: Ollama and HuggingFace
    ✓ Complete conversation memory tracking
    ✓ LangSmith integration for monitoring
    ✓ Professional Gradio web interface
    ✓ Comprehensive documentation and setup scripts
    
    The modular design allows easy customization and extension for your specific needs.
    """
    elements.append(Paragraph(summary_text, body_style))
    
    elements.append(Spacer(1, 0.3*inch))
    
    elements.append(Paragraph("Key Files in This Package", heading2_style))
    files_data = [
        ["File", "Description"],
        ["history_chatbot.py", "Main implementation (Chroma + Ollama)"],
        ["history_chatbot_alternative.py", "Alternative (FAISS + HF option)"],
        ["requirements.txt", "Python dependencies"],
        ["setup.sh", "Automated setup script"],
        ["README.md", "Detailed documentation"],
        ["QUICK_REFERENCE.md", "Quick commands guide"],
    ]
    
    files_table = Table(files_data, colWidths=[2.5*inch, 4*inch])
    files_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5aa0')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.lightblue),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
    ]))
    elements.append(files_table)
    
    elements.append(Spacer(1, 0.5*inch))
    
    footer_text = """
    ---
    Historical Figures Chatbot with LangSmith Integration
    Built with LangChain, Ollama, and Gradio
    © 2025 - Complete Project Documentation
    """
    elements.append(Paragraph(footer_text, body_style))
    
    # Build PDF
    doc.build(elements)
    print(f"✅ PDF created successfully: {output_filename}")
    return output_filename


if __name__ == "__main__":
    # Create the PDF
    pdf_file = create_project_pdf()
    print(f"\n📄 Your project PDF is ready: {pdf_file}")
    print("\nThis PDF contains:")
    print("  • Complete project overview")
    print("  • Setup instructions")
    print("  • Full source code")
    print("  • Configuration examples")
    print("  • Usage guide")
    print("  • Troubleshooting tips")
