# Quick Reference Guide - Historical Figures Chatbot

## 🚀 Quick Start Commands

### First Time Setup
```bash
# 1. Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# 2. Pull required models
ollama pull llama3
ollama pull granite-embedding:latest

# 3. Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# OR
venv\Scripts\activate  # Windows

# 4. Install dependencies
pip install -r requirements.txt

# 5. Set LangSmith variables (optional)
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_PROJECT="Historical-Figures-Chatbot"
export LANGCHAIN_API_KEY="your-api-key-here"
```

### Running the Chatbot
```bash
# Standard version (Chroma + Ollama)
python history_chatbot.py

# Alternative version (FAISS + Optional HuggingFace)
python history_chatbot_alternative.py
```

### Using the Setup Script
```bash
chmod +x setup.sh
./setup.sh
```

## 📝 File Descriptions

| File | Description |
|------|-------------|
| `history_chatbot.py` | Main chatbot (Chroma + Ollama) |
| `history_chatbot_alternative.py` | Alternative (FAISS + HF option) |
| `requirements.txt` | Python dependencies |
| `README.md` | Full documentation |
| `setup.sh` | Automated setup script |
| `sample_historical_figures_content.txt` | Sample content for testing |

## 🔧 Configuration Options

### In `history_chatbot.py`

**Change chunk size:**
```python
text_splitter = CharacterTextSplitter(
    chunk_size=200,      # Increase for longer chunks
    chunk_overlap=30     # Increase for more context
)
```

**Change LLM model:**
```python
llm = Ollama(model="mistral")  # or "llama3", "codellama", etc.
```

**Change retrieval count:**
```python
retriever=vector_store.as_retriever(
    search_kwargs={"k": 5}  # Retrieve more documents
)
```

### In `history_chatbot_alternative.py`

**Switch to HuggingFace:**
```python
USE_HUGGINGFACE = True
HUGGINGFACE_MODEL = "mistralai/Mistral-7B-Instruct-v0.2"
os.environ["HUGGINGFACEHUB_API_TOKEN"] = "your-token"
```

## 🐛 Common Issues & Solutions

### Issue: "PDF not found"
```bash
# Solution: Place PDF in same directory
ls Historical_figures.pdf
# If missing, create a test PDF or check filename
```

### Issue: "Could not connect to Ollama"
```bash
# Solution: Start Ollama service
ollama serve

# Check if running
curl http://localhost:11434/api/tags
```

### Issue: "Model not found"
```bash
# Solution: Pull the model
ollama pull llama3
ollama pull granite-embedding:latest

# Verify models are available
ollama list
```

### Issue: "Module not found"
```bash
# Solution: Install/reinstall requirements
pip install -r requirements.txt

# Or install individually
pip install langchain langchain-community gradio chromadb pypdf
```

### Issue: "LangSmith not working"
```bash
# Solution: Set environment variables
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_API_KEY="your-key"

# Verify they're set
echo $LANGCHAIN_API_KEY
```

### Issue: "Port already in use"
```bash
# Solution: Use different port in code
# Change line: server_port=7860 to server_port=7861
```

### Issue: "Memory error / Slow performance"
```python
# Solution: Reduce chunk size and retrieval count
text_splitter = CharacterTextSplitter(chunk_size=100, chunk_overlap=20)
retriever=vector_store.as_retriever(search_kwargs={"k": 2})
```

## 🎯 Testing the Chatbot

### Sample Questions to Test

1. **Basic facts:**
   - "Who was Albert Einstein?"
   - "Tell me about Marie Curie"

2. **Achievements:**
   - "What were Leonardo da Vinci's accomplishments?"
   - "What did Martin Luther King Jr. do?"

3. **Comparisons:**
   - "Compare Gandhi and Martin Luther King Jr."
   - "What did Einstein and Newton have in common?"

4. **Specific details:**
   - "When did Cleopatra rule Egypt?"
   - "What Nobel Prize did Marie Curie win?"

5. **Out-of-scope (should respond appropriately):**
   - "Who is Elon Musk?" (not in knowledge base)
   - "What's the weather today?" (not relevant)

## 📊 LangSmith Dashboard

Access your traces at: https://smith.langchain.com/

**What to look for:**
- Query processing time
- Retrieved document chunks
- LLM response quality
- Error patterns
- User satisfaction metrics

## 🔄 Updating the Knowledge Base

### To add new historical figures:

1. Edit your PDF or create a new one
2. Delete the vector store:
   ```bash
   rm -rf chroma_db/  # For Chroma version
   rm -rf faiss_index_historical_figures/  # For FAISS version
   ```
3. Run the chatbot again - it will recreate the index

## 🎨 Customizing the UI

### Change greeting message:
```python
# In create_gradio_interface() function
gr.Markdown(
    """
    <div id="greeting">Your custom greeting here!</div>
    """
)
```

### Change colors/styling:
```python
# Modify custom_css variable
custom_css = """
    #chatbot {
        background-color: #f0f0f0;
    }
"""
```

## 📈 Performance Tips

1. **Faster embedding:** Use smaller embedding models
2. **Faster retrieval:** Reduce k value (fewer documents)
3. **Faster generation:** Use smaller LLM or reduce max_tokens
4. **Less memory:** Reduce chunk_size and batch processing

## 🔐 Security Notes

- Never commit API keys to version control
- Use environment variables for sensitive data
- Keep LangSmith API key private
- Consider rate limiting for production use

## 📚 Additional Resources

- LangChain Docs: https://python.langchain.com/
- Ollama Models: https://ollama.ai/library
- LangSmith Guide: https://docs.smith.langchain.com/
- Gradio Docs: https://gradio.app/docs/

## 🆘 Getting Help

If you encounter issues:

1. Check the error message carefully
2. Review this troubleshooting guide
3. Check logs in terminal
4. Verify all dependencies are installed
5. Ensure PDF file exists and is readable
6. Test Ollama independently: `ollama run llama3`

## 📧 Support

For persistent issues:
- Check GitHub issues (if applicable)
- Review LangChain documentation
- Test with sample data first
- Enable verbose logging for debugging

---

**Last Updated:** December 2025
**Version:** 1.0
