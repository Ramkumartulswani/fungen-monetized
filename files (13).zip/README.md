# 🏛️ Historical Figures Chatbot with LangSmith

A Retrieval-Augmented Generation (RAG) chatbot built with LangChain that answers questions about historical figures from a PDF knowledge base, with full LangSmith tracing integration.

## 📋 Features

- **PDF Ingestion**: Load and process historical figures PDF using PyPDFLoader
- **Smart Text Splitting**: CharacterTextSplitter with chunk_size=200 and chunk_overlap=30
- **Vector Store**: Chroma with Ollama Embeddings (granite-embedding:latest)
- **LLM Integration**: Local Ollama model (llama3)
- **Conversation Memory**: In-memory chat history tracking
- **LangSmith Tracing**: Full conversation and retrieval tracing
- **Gradio UI**: User-friendly web interface with chat history

## 🚀 Setup Instructions

### 1. Prerequisites

Ensure you have the following installed:

- Python 3.9 or higher
- [Ollama](https://ollama.ai/) installed and running

### 2. Install Ollama Models

```bash
# Pull the required models
ollama pull llama3
ollama pull granite-embedding:latest

# Verify Ollama is running
ollama serve
```

### 3. Install Python Dependencies

```bash
# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install requirements
pip install -r requirements.txt
```

### 4. Set Up LangSmith (Optional but Recommended)

1. Sign up for a free account at [LangSmith](https://smith.langchain.com/)
2. Get your API key from the settings
3. Set environment variables:

```bash
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_PROJECT="Historical-Figures-Chatbot"
export LANGCHAIN_API_KEY="your-api-key-here"
```

Or add them directly in the script (line 24-27).

### 5. Prepare Your PDF

Place your `Historical_figures.pdf` in the same directory as `history_chatbot.py`.

## 🎮 Running the Chatbot

```bash
python history_chatbot.py
```

The Gradio interface will launch and be accessible at:
- Local: http://localhost:7860
- Network: http://0.0.0.0:7860

## 💻 Usage

1. **Wait for Initialization**: The chatbot will load the PDF, create embeddings, and initialize the vector store
2. **Ask Questions**: Type your question in the text box
3. **Submit**: Click "Submit" or press Enter
4. **Clear History**: Click "Clear History" to reset the conversation

### Example Questions

- "Who was Albert Einstein?"
- "Tell me about Marie Curie's contributions to science"
- "What did Leonardo da Vinci accomplish?"
- "Compare Mahatma Gandhi and Martin Luther King Jr."

## 📁 Project Structure

```
historical-figures-chatbot/
├── history_chatbot.py          # Main chatbot application
├── requirements.txt             # Python dependencies
├── README.md                    # This file
├── Historical_figures.pdf       # Your PDF knowledge base
└── chroma_db/                   # Vector store (auto-created)
```

## 🔧 Configuration

### Customizing the Chatbot

You can modify these parameters in `history_chatbot.py`:

**Text Splitting:**
```python
text_splitter = CharacterTextSplitter(
    chunk_size=200,      # Adjust chunk size
    chunk_overlap=30     # Adjust overlap
)
```

**LLM Settings:**
```python
llm = Ollama(
    model="llama3",      # Change to mistral, etc.
    temperature=0.7      # Adjust creativity (0.0-1.0)
)
```

**Retrieval Settings:**
```python
retriever=vector_store.as_retriever(
    search_kwargs={"k": 3}  # Number of chunks to retrieve
)
```

### Using Different Models

**Alternative LLM Models:**
```python
# For Mistral
llm = Ollama(model="mistral")

# For HuggingFace
from langchain_community.llms import HuggingFaceEndpoint
llm = HuggingFaceEndpoint(
    repo_id="Menlo/Jan-nano-128k",
    huggingfacehub_api_token="your-token"
)
```

**Alternative Vector Store:**
```python
# For FAISS instead of Chroma
from langchain_community.vectorstores import FAISS

vector_store = FAISS.from_documents(
    documents=texts,
    embedding=embeddings
)
vector_store.save_local("historical_figures")
```

## 🐛 Troubleshooting

### Common Issues

**1. PDF Not Found**
```
Error: Historical_figures.pdf not found
Solution: Ensure the PDF is in the same directory as the script
```

**2. Ollama Connection Error**
```
Error: Could not connect to Ollama
Solution: Start Ollama service with 'ollama serve'
```

**3. Model Not Found**
```
Error: Model not found
Solution: Pull the model with 'ollama pull llama3' and 'ollama pull granite-embedding:latest'
```

**4. LangSmith Tracing Not Working**
```
Warning: LANGCHAIN_API_KEY not set
Solution: Set your LangSmith API key in environment variables
```

**5. Memory/Performance Issues**
```
Issue: Slow responses or high memory usage
Solution: Reduce chunk_size or number of retrieved documents (k parameter)
```

## 📊 LangSmith Tracing

When properly configured, LangSmith will track:

- ✅ User queries
- ✅ Retrieved document chunks
- ✅ LLM prompts and responses
- ✅ Chain execution flow
- ✅ Performance metrics

View your traces at: https://smith.langchain.com/

## 🎯 Features Checklist

- [x] PDF ingestion with PyPDFLoader
- [x] Text splitting (chunk_size=200, chunk_overlap=30)
- [x] Chroma vector store with Ollama embeddings
- [x] Local Ollama LLM integration (llama3)
- [x] RetrievalQA with custom prompt template
- [x] In-memory chat message history
- [x] LangSmith tracing integration
- [x] Gradio UI with text input and response area
- [x] Submit and Clear History buttons
- [x] Custom greeting message

## 📝 Code Structure

### Main Functions

1. **initialize_chatbot()**: Sets up PDF loading, vector store, and QA chain
2. **chat()**: Processes user messages and generates responses
3. **clear_history()**: Resets conversation history
4. **create_gradio_interface()**: Builds the web UI
5. **main()**: Entry point for the application

### Key Components

- **PyPDFLoader**: Loads PDF documents
- **CharacterTextSplitter**: Splits text into chunks
- **OllamaEmbeddings**: Generates embeddings using granite-embedding
- **Chroma**: Vector database for similarity search
- **Ollama**: Local LLM for generation
- **RetrievalQA**: QA chain with retrieval
- **ChatMessageHistory**: Tracks conversation
- **Gradio**: Web interface

## 🤝 Contributing

Feel free to enhance this chatbot with:
- Additional vector stores (Pinecone, Weaviate)
- Alternative LLMs (OpenAI, Anthropic)
- Enhanced UI features
- Multi-document support
- Advanced RAG techniques

## 📄 License

This project is provided as-is for educational purposes.

## 🙏 Acknowledgments

- LangChain for the framework
- Ollama for local LLM support
- Gradio for the UI framework
- LangSmith for tracing capabilities

---

**Built with ❤️ using LangChain, Ollama, and Gradio**
