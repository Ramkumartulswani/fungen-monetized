"""
Historical Figures Chatbot with LangSmith Integration
A RAG-based chatbot that answers questions about historical figures from PDF knowledge base.
"""

import os
from typing import List, Tuple
import gradio as gr

# LangChain imports
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.llms import Ollama
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import ChatMessageHistory

# LangSmith configuration
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_PROJECT"] = "Historical-Figures-Chatbot"
# Set your LangSmith API key here or in environment variables
# os.environ["LANGCHAIN_API_KEY"] = "your-api-key-here"

# Global variables
vector_store = None
qa_chain = None
chat_history = ChatMessageHistory()
conversation_memory = None


def initialize_chatbot(pdf_path: str = "Historical_figures.pdf"):
    """
    Initialize the chatbot with PDF loading, vector store creation, and QA chain setup.
    
    Args:
        pdf_path: Path to the Historical_figures.pdf file
    """
    global vector_store, qa_chain, conversation_memory
    
    print("🔄 Initializing Historical Figures Chatbot...")
    
    # Step 1: Load PDF
    print(f"📄 Loading PDF from: {pdf_path}")
    try:
        loader = PyPDFLoader(pdf_path)
        documents = loader.load()
        print(f"✅ Loaded {len(documents)} pages from PDF")
    except Exception as e:
        print(f"❌ Error loading PDF: {e}")
        raise
    
    # Step 2: Split documents
    print("✂️  Splitting documents...")
    text_splitter = CharacterTextSplitter(
        chunk_size=200,
        chunk_overlap=30,
        separator="\n"
    )
    texts = text_splitter.split_documents(documents)
    print(f"✅ Created {len(texts)} text chunks")
    
    # Step 3: Create embeddings
    print("🧠 Initializing Ollama embeddings (granite-embedding:latest)...")
    try:
        embeddings = OllamaEmbeddings(model="granite-embedding:latest")
        print("✅ Embeddings initialized")
    except Exception as e:
        print(f"❌ Error initializing embeddings: {e}")
        raise
    
    # Step 4: Create vector store
    print("🗄️  Creating Chroma vector store...")
    try:
        vector_store = Chroma.from_documents(
            documents=texts,
            embedding=embeddings,
            collection_name="historical_figures",
            persist_directory="./chroma_db"
        )
        print("✅ Vector store created successfully")
    except Exception as e:
        print(f"❌ Error creating vector store: {e}")
        raise
    
    # Step 5: Initialize LLM
    print("🤖 Initializing Ollama LLM (llama3)...")
    try:
        llm = Ollama(
            model="llama3",
            temperature=0.7
        )
        print("✅ LLM initialized")
    except Exception as e:
        print(f"❌ Error initializing LLM: {e}")
        raise
    
    # Step 6: Create custom prompt template
    custom_template = """You are HistoryBot, an expert on historical figures. Use the following pieces of context to answer the question at the end. 
    
If you don't know the answer based on the context provided, just say "I don't have information about that in my knowledge base." Don't try to make up an answer.

Always be informative, accurate, and engaging in your responses about historical figures.

Context: {context}

Question: {question}

Helpful Answer:"""
    
    CUSTOM_PROMPT = PromptTemplate(
        template=custom_template,
        input_variables=["context", "question"]
    )
    
    # Step 7: Initialize conversation memory
    conversation_memory = ConversationBufferMemory(
        chat_memory=chat_history,
        memory_key="chat_history",
        return_messages=True
    )
    
    # Step 8: Create RetrievalQA chain
    print("🔗 Creating RetrievalQA chain...")
    try:
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=vector_store.as_retriever(search_kwargs={"k": 3}),
            chain_type_kwargs={"prompt": CUSTOM_PROMPT},
            return_source_documents=True
        )
        print("✅ QA chain created successfully")
    except Exception as e:
        print(f"❌ Error creating QA chain: {e}")
        raise
    
    print("🎉 Chatbot initialization complete!")
    return "Chatbot initialized successfully!"


def chat(message: str, history: List[Tuple[str, str]]) -> Tuple[str, List[Tuple[str, str]]]:
    """
    Process user message and generate response.
    
    Args:
        message: User input message
        history: Chat history as list of tuples (user_msg, bot_msg)
    
    Returns:
        Tuple of (response, updated_history)
    """
    global qa_chain, chat_history
    
    if qa_chain is None:
        return "⚠️ Chatbot not initialized. Please make sure the PDF is loaded and the system is initialized.", history
    
    try:
        # Add user message to chat history
        chat_history.add_user_message(message)
        
        # Get response from QA chain
        result = qa_chain({"query": message})
        response = result["result"]
        
        # Add assistant response to chat history
        chat_history.add_ai_message(response)
        
        # Update Gradio history
        history.append((message, response))
        
        return "", history
    
    except Exception as e:
        error_msg = f"❌ Error processing your question: {str(e)}"
        history.append((message, error_msg))
        return "", history


def clear_history() -> Tuple[str, List]:
    """
    Clear the chat history.
    
    Returns:
        Empty message and empty history list
    """
    global chat_history
    chat_history.clear()
    return "", []


def create_gradio_interface():
    """
    Create and configure the Gradio interface.
    """
    # Custom CSS for better styling
    custom_css = """
    #chatbot {
        height: 500px;
        overflow-y: auto;
    }
    #title {
        text-align: center;
        font-size: 2em;
        font-weight: bold;
        margin-bottom: 10px;
    }
    #greeting {
        text-align: center;
        font-style: italic;
        color: #666;
        margin-bottom: 20px;
    }
    """
    
    with gr.Blocks(css=custom_css, title="Historical Figures Chatbot") as demo:
        gr.Markdown(
            """
            <div id="title">🏛️ Historical Figures Chatbot</div>
            <div id="greeting">Hello, I am HistoryBot, your expert on historical figures. How can I assist you today?</div>
            """,
            elem_id="header"
        )
        
        chatbot = gr.Chatbot(
            elem_id="chatbot",
            label="Chat History",
            show_label=True,
            height=500
        )
        
        with gr.Row():
            msg = gr.Textbox(
                label="Your Question",
                placeholder="Ask me anything about historical figures...",
                scale=4
            )
        
        with gr.Row():
            submit_btn = gr.Button("Submit", variant="primary", scale=1)
            clear_btn = gr.Button("Clear History", scale=1)
        
        gr.Markdown(
            """
            ### 💡 Tips:
            - Ask about famous historical figures, their achievements, and contributions
            - Request information about specific time periods or events
            - Compare different historical figures
            
            ### 🔧 System Info:
            - **Vector Store**: Chroma with Ollama Embeddings (granite-embedding:latest)
            - **LLM**: Ollama (llama3)
            - **Tracking**: LangSmith enabled for conversation tracing
            """
        )
        
        # Event handlers
        msg.submit(chat, inputs=[msg, chatbot], outputs=[msg, chatbot])
        submit_btn.click(chat, inputs=[msg, chatbot], outputs=[msg, chatbot])
        clear_btn.click(clear_history, outputs=[msg, chatbot])
    
    return demo


def main():
    """
    Main function to run the chatbot application.
    """
    print("=" * 70)
    print("🏛️  HISTORICAL FIGURES CHATBOT WITH LANGSMITH")
    print("=" * 70)
    
    # Check for LangSmith API key
    if "LANGCHAIN_API_KEY" not in os.environ:
        print("\n⚠️  Warning: LANGCHAIN_API_KEY not set in environment variables.")
        print("   LangSmith tracing may not work. Please set it with:")
        print("   export LANGCHAIN_API_KEY='your-api-key-here'")
        print("   or add it directly in the script.\n")
    
    # Initialize chatbot
    pdf_path = "Historical_figures.pdf"
    
    # Check if PDF exists
    if not os.path.exists(pdf_path):
        print(f"\n⚠️  Warning: {pdf_path} not found in current directory.")
        print(f"   Please ensure the PDF file is in the same directory as this script.")
        print(f"   Attempting to continue anyway...\n")
    
    try:
        initialize_chatbot(pdf_path)
    except Exception as e:
        print(f"\n❌ Failed to initialize chatbot: {e}")
        print("\n📋 Troubleshooting steps:")
        print("1. Ensure 'Historical_figures.pdf' is in the current directory")
        print("2. Verify Ollama is installed and running: ollama serve")
        print("3. Pull required models:")
        print("   - ollama pull llama3")
        print("   - ollama pull granite-embedding:latest")
        print("4. Check your LangSmith API key is set correctly")
        return
    
    # Create and launch Gradio interface
    print("\n🚀 Launching Gradio interface...")
    demo = create_gradio_interface()
    demo.launch(
        share=False,
        server_name="0.0.0.0",
        server_port=7860
    )


if __name__ == "__main__":
    main()
